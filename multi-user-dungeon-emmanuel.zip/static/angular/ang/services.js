'use strict';

angular.module('angularFlaskServices', ['ngResource'])
.service('topics', function () {
    return {};
})
